## General Info Session

Friday September 5
UC Connan
5-6 PM

# Modeling

Monday September 9
Modeling Info Session
UC Danforth
4:30-5:30 PM

## Modeling Auditions
Thursday September 11
UC McConomy
4:30-6:30 PM

Friday September 12
UC Peter/Wright/McKenna
4:30-6:30 PM

Saturday September 13
UC Connan
1:00-6:00 PM

Monday September 15
McConomy
1:00-5:00 PM

Tuesday September 16
McConomy
12:00-4:30 PM

Wednesday September 17
McConomy
1:00-3:30 PM

Thursday September 18
McConomy
4:00-6:30 PM

## Modeling Practice Begins

Monday September 22
UC Connan
10:00 PM-12 AM

# Dance

## Dance Info Session

Wednesday September 11
UC McConomy
4:30-5:30 PM

# Design

## Design Info Session

Tuesday September 10
UC Rangos 1
4:30-5:30 PM

## Portfolio Review & Info Session

Tuesday September 24
Location TBD
4:30-5:30 PM

## Portfolios Due by Midnight

October 8
Online Submission